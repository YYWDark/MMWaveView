//
//  MMSubView.h
//  CAShapeLayerDemo
//
//  Created by wyy on 16/11/15.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "MMWaveView.h"

@interface MMSubView : MMWaveView

@end
